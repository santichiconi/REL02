import Entidades.Juego;
import Entidades.Jugador;
import Entidades.RevolverDeAgua;

import java.util.Random;

/**
 * @author chuPac on 6/6/2023.
 * @project Default (Template) Project
 */

public class Main {
    public static void main(String[] args) {

        /*Random random = new Random();*/
        RevolverDeAgua rev = new RevolverDeAgua();
        Juego juego = new Juego();

        rev.llenarRevolver();
        juego.crearJugadores();
        juego.ronda();





    }
}