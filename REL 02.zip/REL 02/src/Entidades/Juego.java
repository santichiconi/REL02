/*

 */

package Entidades;

/*
 * REL 02
 * Santiago Chiconi, Date: 7/6/2023
 */

import java.util.*;

public class Juego {
    Random random = new Random();
    Scanner leer = new Scanner(System.in);
    /*ArrayList<Jugador> Jugadores = new ArrayList<>();*/
    HashMap<Integer, String> Jugadores;

    {
        Jugadores = new HashMap();
    }

    private RevolverDeAgua revolverDeAgua;
    Jugador jug = new Jugador();
    RevolverDeAgua rev = new RevolverDeAgua();

    public Juego() {
    }

    public Juego(HashMap<Integer, String> jugadores, RevolverDeAgua rev) {
        Jugadores = jugadores;
        this.rev = rev;
    }

    public HashMap<Integer, String> getJugadores() {
        return Jugadores;
    }

    public void setJugadores(HashMap<Integer, String> jugadores) {
        Jugadores = jugadores;
    }

    public RevolverDeAgua getRevolverDeAgua() {
        return revolverDeAgua;
    }

    public void setRevolverDeAgua(RevolverDeAgua revolverDeAgua) {
        this.revolverDeAgua = revolverDeAgua;
    }

/*    llenarJuego(ArrayList<Jugador>jugadores
, Revolver r): este método recibe los
jugadores
    y el revolver para guardarlos en
    los atributos del juego.*/

    public void crearJugadores() {
        boolean g = true;
        int j = 0;

        while (g) {
            System.out.print("Ingrese cuantos jugadores participan - Se puede hasta 6 jugadores: ");
            j = leer.nextInt();
            if (j > 6) {
                System.out.println("ERROR Ingrese 6 o menos jugadores");
            } else {
                g = false;
            }
        }
        /*new Jugador(id, nombre);*/
        for (int i = 0; i < j; i++) {
            Integer id = (i+1);
            String nombre = " ";
            System.out.print("Ingrese el nombre del jugador Nro " + id + ": ");
            nombre = leer.next();

            Jugadores.put(id, nombre);
        }
        /*this.setRevolverDeAgua(revolverDeAgua);*/
    }

    /* for (int i = 0; i < 6; i++) {
                    c++;
                    boolean a = rev.mojar();
                    if (a == true) {
                        i = 5;
                        g = false;
                    }
                }*/
    public void ronda() {


        boolean g = true;
        String perdedor = " ";
        /*rev.llenarRevolver();*/

        while (g) {
            for (Map.Entry<Integer, String> mep : Jugadores.entrySet()) {
                Integer key = mep.getKey();
                String str = mep.getValue();
                boolean a = jug.disparo();
                if (a == true) {
                    perdedor = str;
                    g = false;
                    break;
                } else {
                    rev.siguienteChorro();
                    System.out.println("Actual: " + rev.getPosicionActual() + " " + "Agua: " + rev.getPosicionAgua());
                }
            }
        }
        System.out.println("El jugador perdedor fue: " + perdedor);


        }
    }

