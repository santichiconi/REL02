/*

 */

package Entidades;

/*
 * REL 02
 * Santiago Chiconi, Date: 6/6/2023
 */

import java.util.HashMap;

public class Jugador {

    private Integer ID;
    private String nombre;




    RevolverDeAgua rev = new RevolverDeAgua();
    public Jugador() {
    }

    public Jugador(Integer ID, String nombre) {
        this.ID = ID;
        this.nombre = nombre;
    }

    public int getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }



    public boolean disparo() {
        rev.siguienteChorro();
        return rev.mojar();
    }

}